import openpyxl
import re
from typing import List, Dict, Tuple
from parsers import BaseParser
from schema import AccountRow, safe_float, CATEGORY_PL, CATEGORY_MC

PL_KEYWORDS = {
    "Ⅰ. 매출액":     (CATEGORY_PL, "매출", "매출액"),
    "1.제품매출":     (CATEGORY_PL, "매출", "제품매출"),
    "1. Product":    (CATEGORY_PL, "매출", "제품매출"),
    "2 Merchandise": (CATEGORY_PL, "매출", "상품매출"),
    "2. 상품 매출":   (CATEGORY_PL, "매출", "상품매출"),
    "2. Other":      (CATEGORY_PL, "매출", "기타매출"),
    "3. 기타 매출":   (CATEGORY_PL, "매출", "기타매출"),
    "Ⅱ. COST":      (CATEGORY_PL, "매출원가", "매출원가"),
    "Ⅱ. 매출원가":   (CATEGORY_PL, "매출원가", "매출원가"),
    "제품매출원가":    (CATEGORY_PL, "매출원가", "제품매출원가"),
    "상품매출원가":    (CATEGORY_PL, "매출원가", "상품매출원가"),
    "Ⅲ. GROSS":     (CATEGORY_PL, "이익", "매출총이익"),
    "Ⅲ. 매출총이익":  (CATEGORY_PL, "이익", "매출총이익"),
    "Ⅳ. SELLING":   (CATEGORY_PL, "판관비", "판관비계"),
    "Ⅳ.판매관리비":   (CATEGORY_PL, "판관비", "판관비계"),
}

MC_KEYWORDS = {
    "Ⅰ. RAW":       (CATEGORY_MC, "재료비", "재료비계"),
    "Ⅰ. 재료비":     (CATEGORY_MC, "재료비", "재료비계"),
    "Beginning":     (CATEGORY_MC, "재료비", "기초재고"),
    "기초재료":       (CATEGORY_MC, "재료비", "기초재고"),
    "Purchases":     (CATEGORY_MC, "재료비", "당기매입액"),
    "당기재료매입":    (CATEGORY_MC, "재료비", "당기매입액"),
    "Ending":        (CATEGORY_MC, "재료비", "기말재고"),
    "기말재료":       (CATEGORY_MC, "재료비", "기말재고"),
    "Ⅱ. LABOR":     (CATEGORY_MC, "노무비", "노무비계"),
    "Ⅱ. 노무비":     (CATEGORY_MC, "노무비", "노무비계"),
    "Ⅲ. MANUF":     (CATEGORY_MC, "경비", "제조경비계"),
    "Ⅲ. 경비":       (CATEGORY_MC, "경비", "제조경비계"),
    "Electricity":   (CATEGORY_MC, "경비", "전력비"),
    "전력비":         (CATEGORY_MC, "경비", "전력비"),
    "Depreciation":  (CATEGORY_MC, "경비", "감가상각비"),
    "감가상각비":      (CATEGORY_MC, "경비", "감가상각비"),
    "Repair":        (CATEGORY_MC, "경비", "수선비"),
    "수선비":         (CATEGORY_MC, "경비", "수선비"),
    "Consumable":    (CATEGORY_MC, "경비", "소모품비"),
    "소모품비":       (CATEGORY_MC, "경비", "소모품비"),
}

class KsceParser(BaseParser):
    def extract(self) -> List[AccountRow]:
        wb = openpyxl.load_workbook(self.filepath, read_only=True, data_only=True)
        rows = []

        rows.extend(self._extract_pl(wb))
        rows.extend(self._extract_mc(wb))

        wb.close()
        return rows

    def _extract_pl(self, wb) -> List[AccountRow]:
        ws = wb["PL"]
        year = self._detect_year(ws)
        month_start_col = 6  # F = month 1

        row_map = self._build_row_map(ws, PL_KEYWORDS, max_row=80)
        rows = self._extract_monthly(ws, row_map, year, month_start_col, "KSCE", "RSD")

        periods = sorted(set(r.귀속연월 for r in rows))
        for ym in periods:
            gross = sum(r.현지금액 for r in rows if r.귀속연월 == ym and r.계정과목 == "매출총이익")
            sga = sum(r.현지금액 for r in rows if r.귀속연월 == ym and r.계정과목 == "판관비계")
            op = gross - sga
            rows.append(self.make_row(ym, "KSCE", CATEGORY_PL, "이익", "영업이익", "RSD", op))

        return rows

    def _extract_mc(self, wb) -> List[AccountRow]:
        if "MC" not in wb.sheetnames:
            return []
        ws = wb["MC"]
        year = self._detect_year(ws)
        month_start_col = 5  # E = month 1

        row_map = self._build_row_map(ws, MC_KEYWORDS, max_row=40)
        return self._extract_monthly(ws, row_map, year, month_start_col, "KSCE", "RSD")

    def _extract_monthly(self, ws, row_map, year, col_start, corp, currency) -> List[AccountRow]:
        rows = []
        for month_offset in range(12):
            col = col_start + month_offset
            month_num = month_offset + 1

            has_data = False
            for r in row_map:
                v = safe_float(ws.cell(row=r, column=col).value)
                if v != 0:
                    has_data = True
                    break
            if not has_data:
                continue

            ym = f"{year}-{month_num:02d}"
            for row_num, (cat, sub, account) in row_map.items():
                val = safe_float(ws.cell(row=row_num, column=col).value)
                rows.append(self.make_row(ym, corp, cat, sub, account, currency, val))

        return rows

    def _build_row_map(self, ws, keywords, max_row=80) -> Dict[int, Tuple]:
        row_map = {}
        for r in range(1, max_row + 1):
            for col in [2, 3]:  # B and C columns
                cell_val = ws.cell(row=r, column=col).value
                if not cell_val:
                    continue
                cell_str = str(cell_val).strip()
                for kw, mapping in keywords.items():
                    if kw in cell_str:
                        if r not in row_map:
                            row_map[r] = mapping
                        break
        return row_map

    def _detect_year(self, ws) -> str:
        for row in ws.iter_rows(min_row=1, max_row=5, values_only=True):
            for cell in row:
                if cell:
                    m = re.search(r'FY\s*(\d{4})', str(cell))
                    if m:
                        return m.group(1)
                    m = re.search(r'(\d{4})', str(cell))
                    if m and m.group(1) in ("2024", "2025", "2026", "2027"):
                        return m.group(1)
        return "2025"
