using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace KSC_Refiner_UI.Services;

public class AppSettings
{
    public string RootPath { get; set; } = "";
    public string OutputPath { get; set; } = "";
    public string LastYear { get; set; } = "2026";
}

public class SettingsService
{
    private readonly string _configDir;
    private readonly string _settingsPath;
    private readonly string _ratesPath;

    public SettingsService()
    {
        var exeDir = AppDomain.CurrentDomain.BaseDirectory;
        _configDir = Path.Combine(exeDir, "ksc_refiner", "config");
        _settingsPath = Path.Combine(_configDir, "settings.json");
        _ratesPath = Path.Combine(_configDir, "rates.json");
        Directory.CreateDirectory(_configDir);
    }

    public string GetEnginePath()
    {
        var exeDir = AppDomain.CurrentDomain.BaseDirectory;
        return Path.Combine(exeDir, "ksc_refiner", "engine.py");
    }

    public AppSettings Load()
    {
        if (!File.Exists(_settingsPath))
            return new AppSettings();
        var json = File.ReadAllText(_settingsPath);
        var obj = JObject.Parse(json);
        return new AppSettings
        {
            RootPath = obj["root_path"]?.ToString() ?? "",
            OutputPath = obj["output_path"]?.ToString() ?? "",
            LastYear = obj["last_year"]?.ToString() ?? "2026"
        };
    }

    public void Save(AppSettings s)
    {
        var obj = new JObject
        {
            ["root_path"] = s.RootPath,
            ["output_path"] = s.OutputPath,
            ["last_year"] = s.LastYear
        };
        File.WriteAllText(_settingsPath, obj.ToString());
    }

    public Dictionary<string, double> LoadRates(string year)
    {
        if (!File.Exists(_ratesPath))
            return DefaultRates();
        var json = File.ReadAllText(_ratesPath);
        var all = JObject.Parse(json);
        var yearObj = all[year] as JObject;
        if (yearObj == null) return DefaultRates();

        var dict = new Dictionary<string, double>();
        foreach (var prop in yearObj.Properties())
            dict[prop.Name] = prop.Value.Value<double>();
        return dict;
    }

    public void SaveRates(string year, Dictionary<string, double> rates)
    {
        JObject all;
        if (File.Exists(_ratesPath))
        {
            all = JObject.Parse(File.ReadAllText(_ratesPath));
        }
        else
        {
            all = new JObject();
        }

        var yearObj = new JObject();
        foreach (var kv in rates)
            yearObj[kv.Key] = kv.Value;
        all[year] = yearObj;

        File.WriteAllText(_ratesPath, all.ToString());
    }

    private static Dictionary<string, double> DefaultRates() => new()
    {
        ["EUR"] = 1600, ["USD"] = 1350, ["PLN"] = 385,
        ["TRY"] = 40, ["RMB"] = 195, ["RSD"] = 12.5, ["KRW"] = 1
    };
}
