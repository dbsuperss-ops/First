using System.Diagnostics;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace KSC_Refiner_UI.Services;

public class RunResult
{
    public bool Success { get; set; }
    public string? OutputPath { get; set; }
}

public static class PythonRunner
{
    public static async Task<RunResult> RunAsync(
        string enginePath, string rootPath, string year,
        Action<string> onLine)
    {
        var pythonExe = FindPython();
        if (pythonExe == null)
        {
            onLine("Python을 찾을 수 없소. python.exe가 PATH에 등록되어 있는지 확인하시오.");
            return new RunResult { Success = false };
        }

        var psi = new ProcessStartInfo
        {
            FileName = pythonExe,
            Arguments = $"\"{enginePath}\" \"{rootPath}\" \"{year}\"",
            WorkingDirectory = Path.GetDirectoryName(enginePath),
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true,
            StandardOutputEncoding = Encoding.UTF8,
            StandardErrorEncoding = Encoding.UTF8
        };

        string? outputPath = null;
        var success = true;

        try
        {
            using var proc = Process.Start(psi);
            if (proc == null)
            {
                onLine("프로세스 시작 실패.");
                return new RunResult { Success = false };
            }

            var outTask = ReadStreamAsync(proc.StandardOutput, line =>
            {
                onLine(line);
                var match = Regex.Match(line, @"통합 DB 저장:\s*(.+\.xlsx)");
                if (match.Success)
                    outputPath = match.Groups[1].Value.Trim();
            });

            var errTask = ReadStreamAsync(proc.StandardError, line =>
            {
                if (!string.IsNullOrWhiteSpace(line))
                    onLine($"[ERR] {line}");
            });

            await Task.WhenAll(outTask, errTask);
            await proc.WaitForExitAsync();

            if (proc.ExitCode != 0)
                success = false;
        }
        catch (Exception ex)
        {
            onLine($"실행 오류: {ex.Message}");
            success = false;
        }

        return new RunResult { Success = success, OutputPath = outputPath };
    }

    private static async Task ReadStreamAsync(StreamReader reader, Action<string> onLine)
    {
        while (await reader.ReadLineAsync() is { } line)
            onLine(line);
    }

    private static string? FindPython()
    {
        foreach (var name in new[] { "python", "python3", "py" })
        {
            try
            {
                var psi = new ProcessStartInfo
                {
                    FileName = name,
                    Arguments = "--version",
                    UseShellExecute = false,
                    RedirectStandardOutput = true,
                    CreateNoWindow = true
                };
                using var proc = Process.Start(psi);
                if (proc != null)
                {
                    proc.WaitForExit(3000);
                    if (proc.ExitCode == 0) return name;
                }
            }
            catch { }
        }
        return null;
    }
}
