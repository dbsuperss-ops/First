using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Media;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using KSC_Refiner_UI.Services;
using Newtonsoft.Json.Linq;

namespace KSC_Refiner_UI.ViewModels;

public partial class MainViewModel : ObservableObject
{
    private readonly SettingsService _settings;

    [ObservableProperty] private string rootPath = string.Empty;
    [ObservableProperty] private string outputPath = string.Empty;
    [ObservableProperty] private string selectedYear = "2026";
    [ObservableProperty] private string logText = "";
    [ObservableProperty] private string statusText = "대기 중";
    [ObservableProperty] private string statusIcon = "CheckCircleOutline";
    [ObservableProperty] private Brush statusColor = Brushes.Gray;
    [ObservableProperty] private string fileCountText = "";
    [ObservableProperty] private bool canRun = true;
    [ObservableProperty] private bool hasResult = false;
    [ObservableProperty] private string? lastResultPath;

    [ObservableProperty] private double rateEUR = 1600;
    [ObservableProperty] private double rateUSD = 1350;
    [ObservableProperty] private double ratePLN = 385;
    [ObservableProperty] private double rateTRY = 40;
    [ObservableProperty] private double rateRMB = 195;
    [ObservableProperty] private double rateRSD = 12.5;

    public ObservableCollection<string> YearOptions { get; } = new() { "2024", "2025", "2026", "2027" };

    public MainViewModel()
    {
        _settings = new SettingsService();
        LoadSettings();
    }

    private void LoadSettings()
    {
        var s = _settings.Load();
        RootPath = s.RootPath;
        OutputPath = s.OutputPath;
        if (!string.IsNullOrEmpty(s.LastYear))
            SelectedYear = s.LastYear;

        var rates = _settings.LoadRates(SelectedYear);
        RateEUR = rates.GetValueOrDefault("EUR", 1600);
        RateUSD = rates.GetValueOrDefault("USD", 1350);
        RatePLN = rates.GetValueOrDefault("PLN", 385);
        RateTRY = rates.GetValueOrDefault("TRY", 40);
        RateRMB = rates.GetValueOrDefault("RMB", 195);
        RateRSD = rates.GetValueOrDefault("RSD", 12.5);

        AppendLog("프로그램 시작. 루트 경로와 연도를 확인 후 [정제 실행]을 누르시오.");
    }

    partial void OnSelectedYearChanged(string value)
    {
        var rates = _settings.LoadRates(value);
        RateEUR = rates.GetValueOrDefault("EUR", 1600);
        RateUSD = rates.GetValueOrDefault("USD", 1350);
        RatePLN = rates.GetValueOrDefault("PLN", 385);
        RateTRY = rates.GetValueOrDefault("TRY", 40);
        RateRMB = rates.GetValueOrDefault("RMB", 195);
        RateRSD = rates.GetValueOrDefault("RSD", 12.5);
    }

    [RelayCommand]
    private void BrowseFolder()
    {
        var dialog = new Microsoft.Win32.OpenFolderDialog
        {
            Title = "결산 파일 루트 폴더 선택"
        };
        if (dialog.ShowDialog() == true)
        {
            RootPath = dialog.FolderName;
            OutputPath = Path.Combine(RootPath, "output");
            AppendLog($"루트 경로 설정: {RootPath}");
        }
    }

    [RelayCommand]
    private void SaveRates()
    {
        var rates = new Dictionary<string, double>
        {
            ["EUR"] = RateEUR, ["USD"] = RateUSD, ["PLN"] = RatePLN,
            ["TRY"] = RateTRY, ["RMB"] = RateRMB, ["RSD"] = RateRSD, ["KRW"] = 1
        };
        _settings.SaveRates(SelectedYear, rates);
        AppendLog($"{SelectedYear}년 환율 저장 완료.");
    }

    [RelayCommand]
    private async Task Run()
    {
        if (string.IsNullOrWhiteSpace(RootPath) || !Directory.Exists(RootPath))
        {
            MessageBox.Show("유효한 루트 경로를 설정하시오.", "경로 오류", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        CanRun = false;
        HasResult = false;
        StatusText = "실행 중...";
        StatusIcon = "ProgressClock";
        StatusColor = Brushes.Orange;
        LogText = "";

        _settings.Save(new AppSettings { RootPath = RootPath, OutputPath = OutputPath, LastYear = SelectedYear });
        SaveRates();

        AppendLog($"정제 시작: {RootPath} (연도: {SelectedYear})");

        try
        {
            var enginePath = _settings.GetEnginePath();
            if (!File.Exists(enginePath))
            {
                AppendLog($"엔진 파일 미발견: {enginePath}");
                AppendLog("ksc_refiner 폴더가 프로그램 옆에 있는지 확인하시오.");
                return;
            }

            var result = await PythonRunner.RunAsync(
                enginePath, RootPath, SelectedYear,
                line => Application.Current.Dispatcher.Invoke(() => AppendLog(line))
            );

            if (result.Success)
            {
                StatusText = "완료";
                StatusIcon = "CheckCircle";
                StatusColor = Brushes.Green;

                if (!string.IsNullOrEmpty(result.OutputPath) && File.Exists(result.OutputPath))
                {
                    LastResultPath = result.OutputPath;
                    HasResult = true;
                    AppendLog($"\n결과 파일: {result.OutputPath}");
                }
            }
            else
            {
                StatusText = "오류 발생";
                StatusIcon = "AlertCircle";
                StatusColor = Brushes.Red;
            }
        }
        catch (Exception ex)
        {
            AppendLog($"시스템 오류: {ex.Message}");
            StatusText = "오류";
            StatusIcon = "AlertCircle";
            StatusColor = Brushes.Red;
        }
        finally
        {
            CanRun = true;
        }
    }

    [RelayCommand]
    private void OpenResult()
    {
        if (!string.IsNullOrEmpty(LastResultPath) && File.Exists(LastResultPath))
        {
            Process.Start(new ProcessStartInfo(LastResultPath) { UseShellExecute = true });
        }
    }

    private void AppendLog(string line)
    {
        LogText += line + "\n";
    }
}
