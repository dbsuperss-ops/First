using System.Windows;

namespace KSC_Refiner_UI;

public partial class App : Application { }
