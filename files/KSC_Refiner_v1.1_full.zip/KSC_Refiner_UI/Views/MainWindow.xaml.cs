using System.Windows;
using KSC_Refiner_UI.ViewModels;

namespace KSC_Refiner_UI.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        var vm = new MainViewModel();
        DataContext = vm;
        vm.PropertyChanged += (s, e) =>
        {
            if (e.PropertyName == nameof(MainViewModel.LogText))
                LogBox.ScrollToEnd();
        };
    }
}
